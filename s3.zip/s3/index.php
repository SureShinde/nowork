<?php

// Fill These In!
define('S3_BUCKET', 'novumradio');
define('S3_KEY', 	'AKIAJF7YRI443E3SQ5BA');
define('S3_SECRET', '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');
define('S3_ACL', 	'private');
// Stop Here

$policy = json_encode(array(
    'expiration' => date('Y-m-d\TG:i:s\Z', strtotime('+6 hours')),
    'conditions' => array(
        array(
            'bucket' => S3_BUCKET
        ),
        array(
            'acl' => S3_ACL
        ),
        array(
            'starts-with',
            '$key',
            ''
        ),
        array(
            'success_action_status' => '201'
        )
    )
));

$base64Policy = base64_encode($policy);
$signature = base64_encode(hash_hmac("sha1", $base64Policy, S3_SECRET, $raw_output = true));

?>

<!DOCTYPE html>
<html>
<head>
	<title>Direct Upload Example</title>
	<style>
		.progress {
		    position: relative;
		    width: 100%;
		    height: 15px;
		    background: #C7DA9F;
		    border-radius: 10px;
		    overflow: hidden;
		}

		.bar {
		    position: absolute;
		    top: 0;
		    left: 0;
		    width: 0;
		    height: 15px;
		    background: #85C220;
		}

		.bar.red {
		    background: tomato;
		}
	</style>
</head>
<body>

	<!-- Direct Upload to S3 -->
	<!-- URL prefix (//) means either HTTP or HTTPS (depending on which is being currently used) -->
	<form action="http://s3.amazonaws.com/<?php echo S3_BUCKET; ?>/" method="POST" enctype="multipart/form-data" class="direct-upload">

	    <!-- We'll specify these variables with PHP -->
	    <!-- Note: Order of these is Important -->
	    <input type="hidden" name="key" value="${filename}">
	    <input type="hidden" name="AWSAccessKeyId" value="<?php echo S3_KEY; ?>">
	    <input type="hidden" name="acl" value="<?php echo S3_ACL; ?>">
	    <input type="hidden" name="success_action_status" value="201">
	    <input type="hidden" name="policy" value="<?php echo $base64Policy; ?>">
	    <input type="hidden" name="signature" value="<?php echo $signature; ?>">

	    <input type="file" name="file" />

	    <!-- Progress Bar to show upload completion percentage -->
	    <div class="progress"><div class="bar"></div></div>

	</form>

	<!-- Used to Track Upload within our App -->
	<form action="server.php" method="POST">
	    <input type="hidden" name="upload_original_name" id="upload_original_name" />

	    <label for="upload_custom_name">Name:</label><br />
	    <input type="text" name="upload_custom_name" id="upload_custom_name" /><br />

	    <input type="submit" value="Save" />
	</form>


	<script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
	<script src="//code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
	<script src="fileupload/jquery.fileupload.js"></script>
	<script>
		$(document).ready( function() {
		    $('.direct-upload').each( function() {
		        var form = $(this);

		        form.fileupload({
		            url: form.attr('action'),
		            type: 'POST',
		            datatype: 'xml',
		            add: function (event, data) {

		                // Message on unLoad.
		                window.onbeforeunload = function() {
		                    return 'You have unsaved changes.';
		                };

		                // Submit
		                data.submit();
		            },
		            progress: function(e, data){
		                // This is what makes everything really cool, thanks to that callback
		                // you can now update the progress bar based on the upload progress.
		                var percent = Math.round((data.loaded / data.total) * 100);
		                $('.bar').css('width', percent + '%');
		            },
		            fail: function(e, data) {
		                // Remove 'unsaved changes' message.
		                window.onbeforeunload = null;
		                $('.bar').css('width', '100%').addClass('red');
		            },
		            done: function (event, data) {
		        		window.onbeforeunload = null;
		                // Fill the name field with the file's name.
		                $('#upload_original_name').val(data.originalFiles[0].name);
		                $('#upload_custom_name').val(data.originalFiles[0].name);
		            },
		        });
		    });
		});
	</script>

</body>
</html>