if(window.devicePixelRatio)
{
	document.write("<script type=\"text/css\">button.form-button span, button.form-button-alt span {margin: -1px 0px 0px 0px !important;}</script>");
}
$jQuery = jQuery.noConflict();	
