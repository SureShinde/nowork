product_quickview
=================

This Magento extension will add ajax functionality to the product category pages. Users can view a product, select product options, and add to cart without leaving the product category page.
