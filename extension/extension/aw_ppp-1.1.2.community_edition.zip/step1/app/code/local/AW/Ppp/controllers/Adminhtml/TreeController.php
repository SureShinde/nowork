<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Ppp
 * @version    1.1.2
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Ppp_Adminhtml_TreeController extends Mage_Adminhtml_Controller_Action {

    public function getCatChildrensAction($id = null) {

        $category = $this->getRequest()->getParam('category');

        $resource = Mage::getSingleton('core/resource');
        $db = $resource->getConnection('core_read');

        $select = $db->select()
                        ->from($resource->getTableName('catalog/category'), 'entity_id')
                        ->where('parent_id=' . $category);

        $childrens = '';
        foreach ($db->fetchAll($select) as $id) {
            $childrens.=$id['entity_id'] . ',';
        }
        echo substr($childrens, 0, -1);
    }

}
