<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Ppp
 * @version    1.1.2
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Ppp_Block_Previewcontent extends Mage_Core_Block_Template {

    public function getContainerSize() {

        $configImagesize = $this->getConfigImageSize();

        $parametersToReturn = "";

            if ((bool) Mage::getStoreConfig('ppp/ppp_configuration/showproducttitle')) {
                $parametersToReturn = "max-width: " . $configImagesize . "px; max-height: " . ($configImagesize + AW_Ppp_Helper_Config::PRODUCT_NAME_LINE_HEIGHT) . "px;";
            } else {
                $parametersToReturn = "max-width: " . $configImagesize . "px; max-height: " . $configImagesize . "px;";
            }
        return $parametersToReturn;
    }

     public function getImageLineHeight() {

        $result = AW_Ppp_Helper_Config::DEFAULT_IMAGE_RESIZE_PARAM;

        $configImagesize = Mage::getStoreConfig('ppp/ppp_configuration/maximagesize');

        if (is_numeric($configImagesize)) {
            if($configImagesize>0)
               $result = $configImagesize;
        }
        return $result;

    }

    public function displayTitle() {

        $displayTitle = (bool) Mage::getStoreConfig('ppp/ppp_configuration/showproducttitle');
        $res = "display:none;";

        if ($displayTitle) {
            $res = "";
        }

        return $res;
    }

       public function getConfigImageSize() {

        $result = AW_Ppp_Helper_Config::DEFAULT_IMAGE_RESIZE_PARAM;

        $configImagesize = Mage::getStoreConfig('ppp/ppp_configuration/maximagesize');

        if (is_numeric($configImagesize)) {
            if($configImagesize>0)
               $result = $configImagesize;
        }
        return $result;
    }
}
?>
