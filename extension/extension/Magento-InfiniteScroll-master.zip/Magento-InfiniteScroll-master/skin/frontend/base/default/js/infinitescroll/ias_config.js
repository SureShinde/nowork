window.ias_config = {
    // options from https://github.com/webcreate/infinite-ajax-scroll
    // ex. Google Analytics
//    onPageChange: function(pageNum, pageUrl, scrollOffset) {
//        // This will track a pageview every time the user scrolls up or down the screen to a different page.
//        // NOTE: make sure jQuery is already loaded here before using it
//        var path = jQuery('<a/>').attr('href',pageUrl)[0].pathname.replace(/^[^\/]/,'/');
//        _gaq.push(['_trackPageview', path]);
//    }
};
