<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Admingridimages
 * @version    1.0.5
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */

class AW_Admingridimages_Helper_Data extends Mage_Core_Helper_Abstract
{

    public function setDisplayValue($value)
    {
        Mage::getModel('core/config')->saveConfig('awadmingridimages/grid/display', $value);
    }

    public function toOptionArray()
    {
        return $this->getValuesArray();
    }

    public function getStoreId()
    {
        $storesInput = Mage::app()->getFrontController()->getRequest()->getParam('store');
        if(is_array($storesInput) && sizeof($storesInput)) {
            $storeId = $storesInput[0];
        } else {
            $storeId = intval($storesInput);
        }
        return Mage::app()->getStore($storeId)->getId();
    }

    public function getDisplayValue()
    {

        if (!is_null(Mage::app()->getFrontController()->getRequest()->getParam('gridimages'))) {
            $val = Mage::app()->getFrontController()->getRequest()->getParam('gridimages');
        } else {
            $val = Mage::getStoreConfig('awadmingridimages/grid/display', $this->getStoreId());
        }
        return $val;
    }

    public function getDimensionByValue($value = null)
    {
        if (!$value) {
            $value = $this->getDisplayValue();
        }
        switch ($value) {
            case 1:
                return 50;
                break;
            case 2:
                return 100;
                break;
            default:
                return 50;
                break;
        }
    }

    public function getValuesArray()
    {
        return array(
            array('label' => $this->__('No'), 'value' => 0),
            array('label' => $this->__('Small'), 'value' => 1),
            array('label' => $this->__('Large'), 'value' => 2),
        );
    }

    public function isModuleEnabled($moduleName = null)
    {
        if ($moduleName === null) {
            $moduleName = $this->_getModuleName();
        }

        if (!Mage::getConfig()->getNode('modules/' . $moduleName)) {
            return false;
        }

        $isActive = Mage::getConfig()->getNode('modules/' . $moduleName . '/active');
        if (!$isActive || !in_array((string)$isActive, array('true', '1'))) {
            return false;
        }
        return true;
    }
}