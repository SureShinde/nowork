<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This software is designed to work with Magento community edition and
 * its use on an edition other than specified is prohibited. aheadWorks does not
 * provide extension support in case of incorrect edition use.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Admingridimages
 * @version    1.0.5
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */

class AW_Admingridimages_Model_AdminhtmlObserver
{
    public function controllerPredispatch()
    {
        $value = 0;
        if (!is_null(Mage::app()->getFrontController()->getRequest()->getParam('gridimages'))) {
            Mage::helper('awadmingridimages')->setDisplayValue(
                Mage::app()->getFrontController()->getRequest()->getParam('gridimages')
            );
            $value = Mage::app()->getFrontController()->getRequest()->getParam('gridimages');
        }
        if (!$value && !Mage::helper('awadmingridimages')->getDisplayValue()) {
            return;
        }
        if (Mage::getStoreConfig(
            'advanced/modules_disable_output/AW_Admingridimages', Mage::helper('awadmingridimages')->getStoreId()
        )
        ) {
            return;
        }

        $node = Mage::getConfig()->getNode('global/blocks/adminhtml/rewrite');
        $dnodes = Mage::getConfig()->getNode('global/blocks/adminhtml/drewrite');

        foreach ($dnodes->children() as $dnode) {
            $node->appendChild($dnode);
        }
    }
}
