/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/LICENSE-M1.txt
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @copyright  Copyright (c) 2008-2009 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/LICENSE-M1.txt
 */

var customColumnIDs=[];

setCustomColumnIDs = function (key, ids)
{
    customColumnIDs[key]=ids;
};

updateCustomColumnsVisibleCount = function (key, c)
{
    if (arguments.length == 1)
    {
        var c=0;
        for(var i=0; i<customColumnIDs[key].length; i++) {
            var el = $('cb_col_visible_'+key+'_'+customColumnIDs[key][i]);
            if (el && typeof el != 'undefined' && typeof el.checked != 'undefined') {
                c += $(el).checked;
            }
        }
    }
    if (typeof $('customColumnsVisibleCount'+key) != 'undefined')
        $('customColumnsVisibleCount'+key).innerHTML = c;
};

setAllColumnsVisible = function (key, _visible)
{ 
    for(var i=0; i<customColumnIDs[key].length; i++) 
        document.getElementById('cb_col_visible_'+key+'_'+customColumnIDs[key][i]).checked = _visible;
    updateCustomColumnsVisibleCount(key, customColumnIDs[key].length * _visible);
};
