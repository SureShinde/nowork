<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */


class AW_Gridmanager_Block_Adminhtml_Viewfields extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
        $this->_controller = 'adminhtml_viewfields';
        $this->_blockGroup = 'viewfields';

        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('gridmanager/gridmanager')->load($id);

        $this->_headerText = Mage::helper('gridmanager')->__(
            'Columns of %s in %s/%s',
            $model->getGridBlockName(), $model->getControllerName(), $model->getActionName()
        );

        parent::__construct();

        foreach ($this->_buttons[0] as $k => $v) {
            unset($this->_buttons[0][$k]);
        }

        $this->_buttons[-1]['back'] = array(
            'label'   => Mage::helper('gridmanager')->__('Back'),
            'onclick' => "setLocation('" . $this->getUrl('*/*/') . "')",
            'class'   => 'back',
            'area'    => 'header'
        );

        $this->_buttons[-1]['reset'] = array(
            'label'   => Mage::helper('gridmanager')->__('Reset columns to default view'),
            'onclick' => "deleteConfirm('" . Mage::helper('gridmanager')->__(
                'Are you sure you want to reset all columns of %s in %s/%s to default view?',
                $model->getGridBlockName(), $model->getControllerName(), $model->getActionName()
            ) . "', '" . $this->getUrl('*/*/reset', array('id' => $id)) . "gotoindex/1/')",
            'class'   => 'delete',
            'area'    => 'header'
        );

    }
}
