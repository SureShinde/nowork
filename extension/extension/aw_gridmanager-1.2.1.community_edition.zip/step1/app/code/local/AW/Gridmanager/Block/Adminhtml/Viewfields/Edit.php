<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Block_Adminhtml_Viewfields_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    public function __construct()
    {
        parent::__construct();

        $this->_objectId = 'id';
        $this->_blockGroup = 'viewfields';
        $this->_controller = 'adminhtml_viewfields';

        unset($this->_buttons[-1]['reset']);
        unset($this->_buttons[0]['delete']);

        $this->_updateButton(
            'back', 'onclick',
            "setLocation('" . $this->getUrl('*/*/view', array('id' => $this->getRequest()->getParam('id'))) . "')"
        );
        $this->_updateButton('save', 'label', Mage::helper('gridmanager')->__('Save Column'));

        $this->_addButton(
            'saveandcontinue', array(
                                    'label' => Mage::helper('adminhtml')->__('Save And Continue Edit'),
                                    'onclick' => 'saveAndContinueEdit()',
                                    'class' => 'save',
                               ), -100
        );

        $this->_formScripts[]
            = "
            function saveAndContinueEdit(){
                editForm.submit($('edit_form').action+'back/edit/');
            }
        ";
    }

    public function getHeaderText()
    {
        return Mage::helper('gridmanager')->__(
            "Edit Column '%s'", $this->htmlEscape(Mage::registry('gridmanager_data')->getColumnName())
        );
    }
}
