<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Helper_Data extends Mage_Core_Helper_Abstract
{

    protected $columns = array();

    protected $columnOrigin = array(0 => 'Grid', 1 => 'Collection');

    public function getColumns($controller, $action, $gridBlockName)
    {
        $order = 0;
        foreach (
            Mage::getModel('gridmanager/gridmanager')
                ->getColumns($controller, $action, $gridBlockName)
                ->getItems() as $item => $val
        ) {
            $column = $val->getColumnName();
            $this->columns[$column]['index'] = $val->getColumnIndex();
            $this->columns[$column]['header'] = $val->getColumnHeader();
            $this->columns[$column]['align'] = $val->getColumnAlign();
            $this->columns[$column]['width'] = $val->getColumnWidth();
            $this->columns[$column]['order'] = $order += 10;
            $this->columns[$column]['origin'] = $val->getColumnOrigin();
            $this->columns[$column]['visible'] = $val->getColumnIsVisible();
            $this->columns[$column]['system'] = $val->getColumnIsSystem();
            $this->columns[$column]['column_id'] = $val->getId();
        }
        return $this->columns;
    }

    public function getColumnIds($controller, $action, $gridBlockName)
    {
        $columnIds = array();
        foreach (
            Mage::getModel('gridmanager/gridmanager')
                ->getColumns($controller, $action, $gridBlockName)
                ->getItems() as $item => $val
        ) {
            $columnIds[$val->getId()] = '';
        }
        return $columnIds;
    }

    public function getColumnsUrl($action = 'view')
    {
        $data = Mage::app()->getRequest()->getParams();

        return Mage::getSingleton('adminhtml/url')->getUrl(
            'gridmanager/adminhtml_gridmanager/' . $action,
            array('cn' => $data['cn'], 'an' => $data['an'], 'gn' => $data['gn'])
        );
    }

    public function getColumnOriginText($origin)
    {
        return $this->columnOrigin[$origin];
    }

    public function getGridControllerAndAction($url)
    {
        $baseUrl = Mage::helper('adminhtml')->getUrl('adminhtml');
        $path = str_replace($baseUrl, '', $url);
        $params = explode('/', $path);
        $controller = $params[0];
        $action = 'index';
        if (isset($params[1])) {
            $action = $params[1];
        }

        //if extension doesn't use adminhtml path in url
        if ($path == $url) {
            $path = str_replace(Mage::helper('adminhtml')->getUrl(), '', $url);
            $params = explode('/', $path);
            $action = 'index';
            $controller = $params[1];
            if (isset($params[2])) {
                $action = $params[2];
            }
        }

        return $controller . '/' . $action;
    }

    public function isAllowedController()
    {
        $allowed = true;
        switch (Mage::app()->getRequest()->getControllerName()) {
            case 'sales_order_create':
                $allowed = false;
                break;
        }
        return $allowed;
    }
}
