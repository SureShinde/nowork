<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Block_Adminhtml_Viewfields_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset(
            'gridmanager_form', array('legend' => Mage::helper('gridmanager')->__('Item information'))
        );

        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('gridmanager/gridmanager')->load($id);

        $fieldset->addField(
            'column_name', 'text', array(
                                        'label'              => Mage::helper('gridmanager')->__('Column Name'),
                                        'required'           => false,
                                        'name'               => 'column_name',
                                        'style'              => 'display:none',
                                        'after_element_html' =>
                                        '<span style="field-label">' . $model->getColumnName() . '</span>',
                                   )
        );

        $fieldset->addField(
            'column_index', 'text', array(
                                         'label'              => Mage::helper('gridmanager')->__('Column Field Name'),
                                         'required'           => false,
                                         'name'               => 'column_index',
                                         'style'              => 'display:none',
                                         'after_element_html' =>
                                         '<span style="field-label">' . $model->getColumnIndex() . '</span>',
                                    )
        );

        $fieldset->addField(
            'column_header', 'text', array(
                                          'label'    => Mage::helper('gridmanager')->__('Header'),
                                          'required' => false,
                                          'name'     => 'column_header',
                                     )
        );

        $fieldset->addField(
            'column_origin', 'text', array(
                                          'label'              => Mage::helper('gridmanager')->__('Column Origin'),
                                          'required'           => false,
                                          'name'               => 'column_origin',
                                          'style'              => 'display:none',
                                          'after_element_html' =>
                                          '<span style="field-label">' . Mage::helper('gridmanager')
                                              ->getColumnOriginText($model->getColumnOrigin()) . '</span>',
                                     )
        );

        $fieldset->addField(
            'column_is_visible', 'select', array(
                                                'label'  => Mage::helper('gridmanager')->__('Is Visible'),
                                                'name'   => 'column_is_visible',
                                                'values' => array(
                                                    array(
                                                        'value' => 0,
                                                        'label' => Mage::helper('gridmanager')->__('No'),
                                                    ),
                                                    array(
                                                        'value' => 1,
                                                        'label' => Mage::helper('gridmanager')->__('Yes'),
                                                    ),
                                                ),
                                           )
        );

        $fieldset->addField(
            'column_width', 'text', array(
                                         'label'    => Mage::helper('gridmanager')->__('Width'),
                                         'required' => false,
                                         'name'     => 'column_width',
                                    )
        );

        $fieldset->addField(
            'column_align', 'select', array(
                                           'label'  => Mage::helper('gridmanager')->__('Align'),
                                           'name'   => 'column_align',
                                           'values' => array(
                                               array(
                                                   'value' => 'left',
                                                   'label' => Mage::helper('gridmanager')->__('Left'),
                                               ),
                                               array(
                                                   'value' => 'center',
                                                   'label' => Mage::helper('gridmanager')->__('Center'),
                                               ),
                                               array(
                                                   'value' => 'right',
                                                   'label' => Mage::helper('gridmanager')->__('Right'),
                                               ),
                                           ),
                                      )
        );

        if (Mage::getSingleton('adminhtml/session')->getGridmanagerData()) {
            $form->setValues(Mage::getSingleton('adminhtml/session')->getGridmanagerData());
            Mage::getSingleton('adminhtml/session')->setGridmanagerData(null);
        } elseif (Mage::registry('gridmanager_data')) {
            $form->setValues(Mage::registry('gridmanager_data')->getData());
        }
        return parent::_prepareForm();
    }
}