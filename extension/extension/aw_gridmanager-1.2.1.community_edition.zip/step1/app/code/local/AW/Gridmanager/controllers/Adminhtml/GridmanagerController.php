<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Adminhtml_GridmanagerController extends Mage_Adminhtml_Controller_action
{

    protected function _initAction()
    {
        $this->loadLayout()
            ->_setActiveMenu('gridmanager/items')
            ->_addBreadcrumb(
                Mage::helper('adminhtml')->__('Items Manager'), Mage::helper('adminhtml')->__('Item Manager')
            );
        return $this;
    }

    public function indexAction()
    {
        $this->_initAction()
            ->renderLayout();
    }

    public function viewAction()
    {
        $this->_initAction()
            ->renderLayout();
    }

    public function editAction()
    {
        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('gridmanager/gridmanager')->load($id);

        if ($model->getId() || $id == 0) {
            $data = Mage::getSingleton('adminhtml/session')->getFormData(true);
            if (!empty($data)) {
                $model->setData($data);
            }

            Mage::register('gridmanager_data', $model);

            $this->loadLayout();
            $this->_setActiveMenu('gridmanager/items');

            $this->_addBreadcrumb(
                Mage::helper('adminhtml')->__('Item Manager'), Mage::helper('adminhtml')->__('Item Manager')
            );
            $this->_addBreadcrumb(
                Mage::helper('adminhtml')->__('Item News'), Mage::helper('adminhtml')->__('Item News')
            );

            $this->getLayout()->getBlock('head')->setCanLoadExtJs(true);

            $this->_addContent($this->getLayout()->createBlock('gridmanager/adminhtml_viewfields_edit'))
                ->_addLeft($this->getLayout()->createBlock('gridmanager/adminhtml_viewfields_edit_tabs'));

            $this->renderLayout();
        } else {
            Mage::getSingleton('adminhtml/session')->addError(Mage::helper('gridmanager')->__('Item does not exist'));
            $this->_redirectReferer();
        }
    }

    public function saveAction()
    {
        if ($data = $this->getRequest()->getPost()) {
            $model = Mage::getModel('gridmanager/gridmanager');

            if ($id = $this->getRequest()->getParam('id')) {
                $model->load($id);
                if ($id != $model->getId()) {
                    Mage::getSingleton('adminhtml/session')->addError(
                        Mage::helper('gridmanager')->__('The page you are trying to save no longer exists')
                    );
                    $this->_redirect('*/*/index');
                    return;
                }
            }

            $model->setData($data)->setId($id);
            try {
                $model->save();
                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('gridmanager')->__('Column %s was successfully saved', $model->getColumnName())
                );

                if ($this->getRequest()->getParam('back')) {
                    $this->_redirect('*/*/edit', array('id' => $id));
                } else {
                    $this->_redirect('*/*/view', array('id' => $id));
                }
                return;
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError($e->getMessage());
                $this->_redirect('*/*/index');
                return;
            }
        }
        Mage::getSingleton('adminhtml/session')->addError(
            Mage::helper('gridmanager')->__('Unable to find item to save')
        );
        $this->_redirect('*/*/index');
    }

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

    public function saveAllAction()
    {
        if ($data = $this->getRequest()->getPost()) {
            try {
                foreach (explode(' ', $data['recordsToRemove']) as $k) {
                    $model = Mage::getModel('gridmanager/gridmanager');
                    $model->setId($k);
                    $model->delete();
                }
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError(
                    Mage::helper('gridmanager')
                        ->__('Cannot delete unneeded column ID=') . $model->getId() . $e->getMessage()
                );
            }

            try {
                foreach ($data['cf'] as $k => $v) {
                    $model = Mage::getModel('gridmanager/gridmanager');

                    if ((int)$v['id'] !== -1) {
                        $model->setId($v['id']);
                    }

                    $model->setControllerName($data['controllerName']);
                    $model->setActionName($data['actionName']);
                    $model->setGridBlockName($data['gridBlockName']);
                    $model->setColumnName($k);
                    $model->setColumnIndex($v['index']);
                    $model->setColumnHeader($v['header']);
                    $model->setColumnWidth($v['width']);
                    $model->setColumnAlign($v['alignment']);
                    $model->setColumnOrder($v['order']);
                    $model->setColumnOrigin($v['origin']);
                    $model->setColumnIsVisible((int)isset($v['visible']));
                    $model->setColumnIsSystem((int)$v['system']);

                    $model->save();
                }
                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('gridmanager')->__('Columns were successfully saved')
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError(
                    Mage::helper('gridmanager')->__('Cannot save columns') . '<br>' . $e->getMessage()
                );
            }
        }
        $this->_redirectReferer();
    }

    public function resetAction()
    {
        if ($id = $this->getRequest()->getParam('id')) {
            $model = Mage::getModel('gridmanager/gridmanager')->load($id);

            $controllerName = $model->getControllerName();
            $actionName = $model->getActionName();
            $gridBlockName = $model->getGridBlockName();

            try {
                $columnIds = Mage::helper('gridmanager')->getColumnIds($controllerName, $actionName, $gridBlockName);

                foreach ($columnIds as $k => $v) {
                    Mage::getModel('gridmanager/gridmanager')->setId($k)->delete();
                }

                Mage::getSingleton('adminhtml/session')->addSuccess(
                    Mage::helper('gridmanager')->__(
                        'Columns in %s / %s / %s were successfully reset', $controllerName, $actionName, $gridBlockName
                    )
                );
            } catch (Exception $e) {
                Mage::getSingleton('adminhtml/session')->addError(
                    Mage::helper('gridmanager')->__(
                        'Cannot reset columns of %s / %s / %s', $controllerName, $actionName, $gridBlockName
                    ) . '<br>' . $e->getMessage()
                );
            }

            if ($this->getRequest()->getParam('gotoindex')) {
                $this->_redirect('*/*/index');
            } else {
                $this->_redirectReferer();
            }
        }
    }

}
