<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Block_Adminhtml_Viewfields_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('viewfieldsGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $id = $this->getRequest()->getParam('id');
        $model = Mage::getModel('gridmanager/gridmanager')->load($id);
        if ($id == $model->getId()) {
            $collection = $model->getCollection();
            $collection->getSelect()
                ->where('controller_name=?', $model->getControllerName())
                ->where('action_name=?', $model->getActionName())
                ->where('grid_block_name=?', $model->getGridBlockName())
                ->order('column_order');
            $this->setCollection($collection);

            return parent::_prepareCollection();
        }
    }

    protected function _prepareColumns()
    {
        $this->setPagerVisibility(0);
        $this->setFilterVisibility(0);

        $this->addColumn(
            'column_name', array(
                                'header' => Mage::helper('gridmanager')->__('Column Name'),
                                'align'  => 'left',
                                'index'  => 'column_name',
                           )
        );

        $this->addColumn(
            'column_index', array(
                                 'header' => Mage::helper('gridmanager')->__('Field Name'),
                                 'align'  => 'left',
                                 'index'  => 'column_index',
                            )
        );

        $this->addColumn(
            'column_header', array(
                                  'header' => Mage::helper('gridmanager')->__('Column Header'),
                                  'align'  => 'left',
                                  'index'  => 'column_header',
                             )
        );

        $this->addColumn(
            'column_origin', array(
                                  'header'  => Mage::helper('gridmanager')->__('Column Origin'),
                                  'align'   => 'left',
                                  'width'   => '100px',
                                  'index'   => 'column_origin',
                                  'type'    => 'options',
                                  'options' => array(
                                      0 => 'Grid',
                                      1 => 'Collection',
                                  ),
                             )
        );

        $this->addColumn(
            'column_is_visible', array(
                                      'header'  => Mage::helper('gridmanager')->__('Is Visible'),
                                      'align'   => 'center',
                                      'width'   => '80px',
                                      'index'   => 'column_is_visible',
                                      'type'    => 'options',
                                      'options' => array(
                                          0 => 'No',
                                          1 => 'Yes',
                                      ),
                                 )
        );

        $this->addColumn(
            'column_is_system', array(
                                     'header'  => Mage::helper('gridmanager')->__('Is System'),
                                     'align'   => 'center',
                                     'width'   => '80px',
                                     'index'   => 'column_is_system',
                                     'type'    => 'options',
                                     'options' => array(
                                         0 => 'No',
                                         1 => 'Yes',
                                     ),
                                )
        );

        $this->addColumn(
            'column_align', array(
                                 'header' => Mage::helper('gridmanager')->__('Column Alignment'),
                                 'align'  => 'left',
                                 'width'  => '80px',
                                 'index'  => 'column_align',
                            )
        );

        $this->addColumn(
            'column_width', array(
                                 'header' => Mage::helper('gridmanager')->__('Column Width'),
                                 'align'  => 'right',
                                 'width'  => '80px',
                                 'index'  => 'column_width',
                            )
        );

        $this->addColumn(
            'column_order', array(
                                 'header' => Mage::helper('gridmanager')->__('Column Order'),
                                 'align'  => 'right',
                                 'width'  => '50px',
                                 'index'  => 'column_order',
                            )
        );

        $this->addColumn(
            'action',
            array(
                 'header'    => Mage::helper('gridmanager')->__('Action'),
                 'width'     => '50px',
                 'type'      => 'action',
                 'getter'    => 'getId',
                 'actions'   => array(
                     array(
                         'caption' => Mage::helper('gridmanager')->__('Edit'),
                         'url'     => array('base' => '*/*/edit'),
                         'field'   => 'id'
                     ),
                 ),
                 'filter'    => false,
                 'sortable'  => false,
                 'index'     => 'stores',
                 'is_system' => true,
            )
        );

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/edit', array('id' => $row->getId()));
    }

}
