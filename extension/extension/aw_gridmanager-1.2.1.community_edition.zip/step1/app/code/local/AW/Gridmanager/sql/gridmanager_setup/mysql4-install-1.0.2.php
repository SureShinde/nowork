<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



$installer = $this;

$installer->startSetup();

$installer->run("
CREATE TABLE {$this->getTable('gridmanager/gridmanager')} (
 `id` int(10) unsigned NOT NULL auto_increment,
 `controller_name` varchar(255) character set utf8 NOT NULL,
 `action_name` varchar(255) character set utf8 NOT NULL,
 `grid_block_name` varchar(255) character set utf8 NOT NULL,
 `column_name` varchar(255) character set utf8 NOT NULL,
 `column_index` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
 `column_width` varchar(128) character set utf8 default '',
 `column_align` varchar(128) character set utf8 default 'left',
 `column_header` varchar(255) character set utf8 default '',
 `column_order` int(10) NOT NULL default '0',
 `column_origin` tinyint(1) NOT NULL default '0',
 `column_is_visible` tinyint(1) NOT NULL default '1',
 `column_is_system` tinyint(1) NOT NULL default '0',
 PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
");

$installer->endSetup(); 