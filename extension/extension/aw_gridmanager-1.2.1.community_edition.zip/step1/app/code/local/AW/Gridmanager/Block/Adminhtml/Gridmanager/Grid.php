<?php
/**
 * aheadWorks Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://ecommerce.aheadworks.com/AW-LICENSE.txt
 *
 * =================================================================
 *                 MAGENTO EDITION USAGE NOTICE
 * =================================================================
 * This package designed for Magento community edition
 * aheadWorks does not guarantee correct work of this extension
 * on any other Magento edition except Magento community edition.
 * aheadWorks does not provide extension support in case of
 * incorrect edition usage.
 * =================================================================
 *
 * @category   AW
 * @package    AW_Gridmanager
 * @version    1.2.1
 * @copyright  Copyright (c) 2010-2012 aheadWorks Co. (http://www.aheadworks.com)
 * @license    http://ecommerce.aheadworks.com/AW-LICENSE.txt
 */



class AW_Gridmanager_Block_Adminhtml_Gridmanager_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->setId('gridmanagerGrid');
        $this->setDefaultSort('id');
        $this->setDefaultDir('ASC');
        $this->setSaveParametersInSession(true);
    }

    protected function _prepareCollection()
    {
        $collection = Mage::getModel('gridmanager/gridmanager')->getCollection();
        $collection->getSelect()->group(array('controller_name', 'action_name', 'grid_block_name'));
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    protected function _prepareColumns()
    {
        $this->addColumn(
            'controllerName', array(
                                   'header' => Mage::helper('gridmanager')->__('Controller Name'),
                                   'align'  => 'left',
                                   'index'  => 'controller_name',
                              )
        );

        $this->addColumn(
            'actionName', array(
                               'header' => Mage::helper('gridmanager')->__('Action Name'),
                               'align'  => 'left',
                               'index'  => 'action_name',
                          )
        );

        $this->addColumn(
            'gridBlockName', array(
                                  'header' => Mage::helper('gridmanager')->__('Grid Block Name In Layout'),
                                  'align'  => 'left',
                                  'index'  => 'grid_block_name',
                             )
        );

        $this->addColumn(
            'resetAction',
            array(
                 'header'    => Mage::helper('gridmanager')->__('Action'),
                 'width'     => '100',
                 'type'      => 'action',
                 'getter'    => 'getId',
                 'actions'   => array(
                     array(
                         'caption' => Mage::helper('gridmanager')->__('Reset columns'),
                         'url'     => array('base' => '*/*/reset'),
                         'field'   => 'id',
                         'confirm' => Mage::helper('gridmanager')->__(
                             'Are you sure you want to reset all columns to default view?'
                         ),
                     )
                 ),
                 'filter'    => false,
                 'sortable'  => false,
                 'index'     => 'stores',
                 'is_system' => true,
            )
        );

        return parent::_prepareColumns();
    }

    public function getRowUrl($row)
    {
        return $this->getUrl('*/*/view', array('id' => $row->getId()));
    }

}