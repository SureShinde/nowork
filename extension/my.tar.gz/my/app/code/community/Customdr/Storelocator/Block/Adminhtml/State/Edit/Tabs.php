<?php
/**
 * @uses   class used for preparing tabs in state form
 */
  class Customdr_Storelocator_Block_Adminhtml_State_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
  {
     public function __construct()
     {
          parent::__construct();
          $this->setId('state_data');
          $this->setDestElementId('edit_form');
          $this->setTitle('Edit State');
      }
      protected function _beforeToHtml()
      {
          $this->addTab('form_section', array(
                   'label' => 'State Information',
                   'title' => 'State Information',
                   'content' => $this->getLayout()
     ->createBlock('storelocator/adminhtml_state_edit_tab_form')
     ->toHtml()
         ));
         return parent::_beforeToHtml();
    }
}