<?php
class Customdr_Storelocator_Block_Adminhtml_Country extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
     //where is the controller
     $this->_controller = 'adminhtml_country';
     $this->_blockGroup = 'storelocator';
     //text in the admin header
     $this->_headerText = Mage::helper('storelocator')->__('Country Manager');
     //value of the add button
     $this->_addButtonLabel = 'Add New Country';
     parent::__construct();
     }
}