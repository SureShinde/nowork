<?php
class Customdr_Storelocator_Block_Adminhtml_Store extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
     //where is the controller
     $this->_controller = 'adminhtml_store';
     $this->_blockGroup = 'storelocator';
     //text in the admin header
     $this->_headerText = Mage::helper('storelocator')->__('Store Manager');
     //value of the add button
     $this->_addButtonLabel = 'Add New Store';
     parent::__construct();
     }
}