<?php
/**
 * @uses   class used for genaral setting of all blocks in module
 */
class Customdr_Storelocator_Helper_Data extends Mage_Core_Helper_Abstract
{

}

?>