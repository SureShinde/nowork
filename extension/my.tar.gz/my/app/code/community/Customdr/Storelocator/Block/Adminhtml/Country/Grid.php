<?php
 /**
 * @uses   class used for preparing grid list of all countries
 */
class Customdr_Storelocator_Block_Adminhtml_Country_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
    parent::__construct();
    $this->setId('countryGrid');
    $this->setDefaultSort('country_id');
    $this->setDefaultDir('DESC');
    $this->setSaveParametersInSession(true);
  }
  /**
   * @uses   function used to get collection of all countries
  */
  protected function _prepareCollection()
  {
    $collection = Mage::getModel('storelocator/country')->getCollection();
    $this->setCollection($collection);
    return parent::_prepareCollection();
  }
  /**
   * @uses   function used to peprare columns of grid list
  */
  protected function _prepareColumns()
  {
    $this->addColumn('country_id',
     array(
            'header' => 'ID',
            'align' =>'right',
            'width' => '50px',
            'index' => 'country_id',
       ));
    $this->addColumn('country_name',
       array(
            'header' => 'Country Name',
            'align' =>'left',
            'index' => 'country_name',
      ));
    $this->addColumn('status',
       array(
            'header' => 'Status',
            'align' =>'left',
            'index' => 'status',
            'type'      => 'options',
            'options'    => array('0' => 'Enable','1' => 'Disable')
      ));
    $this->addColumn('sort',
       array(
            'header' => 'Sort Order',
            'align' =>'left',
            'index' => 'sort',
      ));
    return parent::_prepareColumns();
  }
  /**
   * @uses   function used to peprare edit url
  */
  public function getRowUrl($row)
  {
      return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }
}