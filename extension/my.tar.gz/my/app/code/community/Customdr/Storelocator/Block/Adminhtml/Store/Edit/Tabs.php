<?php
/**
 * @uses   class used for preparing tabs in state form
 */
  class Customdr_Storelocator_Block_Adminhtml_Store_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
  {
     public function __construct()
     {
          parent::__construct();
          $this->setId('store_data');
          $this->setDestElementId('edit_form');
          $this->setTitle('Edit State');
      }
      protected function _beforeToHtml()
      {
          $this->addTab('form_section', array(
                   'label' => 'Store Information',
                   'title' => 'Store Information',
                   'content' => $this->getLayout()
     ->createBlock('storelocator/adminhtml_store_edit_tab_form')
     ->toHtml()
         ));
         return parent::_beforeToHtml();
    }
}