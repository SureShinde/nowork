<?php
class Customdr_Gallery_Adminhtml_IndexController extends Mage_Adminhtml_Controller_Action
{
    protected function _initAction()
    {
      $this->loadLayout();
       return $this;
     }
      public function indexAction()
      { $this->loadLayout()->_setActiveMenu('gallery/gallery');
        $this->_addContent($this->getLayout()->createBlock('gallery/adminhtml_allimages'));
        $this->renderLayout();
      }
      public function editAction()
      {
           $testId = $this->getRequest()->getParam('id');
           $testModel = Mage::getModel('gallery/gallery')->load($testId);
           if ($testModel->getId() || $testId == 0)
           {
             Mage::register('gallery_data', $testModel);
             $this->loadLayout();
             $this->_setActiveMenu('gallery/set_time');
             $this->_addBreadcrumb('gallery Manager', 'gallery Manager');
             $this->_addBreadcrumb('gallery Description', 'gallery Description');
             $this->getLayout()->getBlock('head')
                  ->setCanLoadExtJs(true);
             $this->_addContent($this->getLayout()
                  ->createBlock('gallery/adminhtml_allimages_edit'))
                  ->_addLeft($this->getLayout()
                  ->createBlock('gallery/adminhtml_allimages_edit_tabs')
              );
             $this->renderLayout();
           }
           else
           {
                 Mage::getSingleton('adminhtml/session')
                       ->addError('Test does not exist');
                 $this->_redirect('*/*/');
            }
       }
       public function newAction()
       {
          $this->_forward('edit');
       }
       public function saveAction()
       {


        if ($this->getRequest()->getPost())
         {
            if($_FILES['image']['name'] != '') {

                try {    
                     $uploader = new Varien_File_Uploader('image');
                     $uploader->setAllowedExtensions(array('jpg','jpeg','gif','png'));
                     $uploader->setAllowRenameFiles(false);
                     $uploader->setFilesDispersion(false);
                 
                     $path = Mage::getBaseDir('media') . DS ;
                            
                     $uploader->save($path, $_FILES['image']['name']);
                } catch (Exception $e) {
                      
                }

                $data['image'] = $_FILES['image']['name'];

            }
             else {        
                    if(isset($data['image']['delete']) && $data['image']['delete'] == 1)
                         $data['image'] = '';
                    else 
                        unset($data['image']);
            } 

           try {
                 $postData = $this->getRequest()->getPost();
                 $testModel = Mage::getModel('gallery/gallery');
               if( $this->getRequest()->getParam('id') <= 0 )
                  $testModel->setCreatedTime(
                     Mage::getSingleton('core/date')
                            ->gmtDate()
                    );


                  if(isset($postData['image']['delete']) && $postData['image']['delete'] == 1)
                  {
                    unset($postData['image']);
                    $postData['image'] = "";
                    
                  }
                  else
                  { 
                    unset($postData['image']);
                    $postData['image'] = $data['image'];
                  }
                
                  $testModel
                    ->addData($postData)
                    ->setUpdateTime(
                             Mage::getSingleton('core/date')
                             ->gmtDate())
                    ->setId($this->getRequest()->getParam('id'))
                    ->save();
                 Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully saved');
                 Mage::getSingleton('adminhtml/session')
                                ->settestData(false);
                 $this->_redirect('*/*/');
                return;
          } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')
                                  ->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')
                 ->settestData($this->getRequest()
                                    ->getPost()
                );
                $this->_redirect('*/*/edit',
                            array('id' => $this->getRequest()
                                                ->getParam('id')));
                return;
                }
              }
              $this->_redirect('*/*/');
            }
          


          public function deleteAction()
          {
              if($this->getRequest()->getParam('id') > 0)
              {
                try
                {
                    $testModel = Mage::getModel('gallery/gallery');
                    $testModel->setId($this->getRequest()
                                        ->getParam('id'))
                              ->delete();
                    Mage::getSingleton('adminhtml/session')
                               ->addSuccess('successfully deleted');
                    $this->_redirect('*/*/');
                 }
                 catch (Exception $e)
                  {
                           Mage::getSingleton('adminhtml/session')
                                ->addError($e->getMessage());
                           $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
                  }
             }
            $this->_redirect('*/*/');
       }
}
?>