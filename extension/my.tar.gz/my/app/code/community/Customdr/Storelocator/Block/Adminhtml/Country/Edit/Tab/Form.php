<?php
/**
 * @uses   class used for preparing country form
 */
class Customdr_Storelocator_Block_Adminhtml_Country_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  /**
   * @uses   function used for preparing all the fields of country form
   */
  protected function _prepareForm()
  {
    $form = new Varien_Data_Form();
    $this->setForm($form);
    $fieldset = $form->addFieldset('country_form',
                array('legend'=>'Country Information'));
    $fieldset->addField('country_name', 'text',
                   array(
                      'label' => 'Country Name',
                      'class' => 'required-entry',
                      'required' => true,
                       'name' => 'country_name',
                ));

    $fieldset->addField('country_code', 'text',
                   array(
                      'label' => 'Country Code',
                      'class' => 'required-entry',
                      'required' => true,
                       'name' => 'country_code',
                ));

    $note = "enble / disable";
    $fieldset->addField('status', 'select', array(
                'name'      => 'status',
                'label'     => "Status",
                'title'     => "Status",
                'required'  => true,
                'note'      => $note,
                'values'    => array('0' => array( 'value' => 0, 'label' => Enable ),
'1' => array( 'value' => 1, 'label' => Disable )),
          ));

    $note = "yes / no &nbsp;&nbsp; (Note: Select 'yes' if Country Contains Maximum Num. of Stores)";
    $fieldset->addField('maincountry', 'select', array(
                'name'      => 'maincountry',
                'label'     => "Is Main country ?",
                'title'     => "Is Main country ?",
                'required'  => true,
                'note'      => $note,
                'values'    => array('0' => array( 'value' => 0, 'label' => No ),
'1' => array( 'value' => 1, 'label' => Yes )),
          ));

    $note = "enter text for state label for your country";
    $fieldset->addField('state_label', 'text',
                       array(
                          'label' => 'State Label',
                           'name' => 'state_label',
                           'note'      => $note
                    ));

    $fieldset->addField('sort', 'text',
                       array(
                          'label' => 'Sort Order',
                          'class' => 'required-entry',
                          'required' => true,
                           'name' => 'sort',
                    ));
    if ( Mage::registry('country_data') )
    {
      $form->setValues(Mage::registry('country_data')->getData());
    }
    return parent::_prepareForm();
  }
}