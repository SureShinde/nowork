<?php
class Customdr_Storelocator_Block_Country extends Mage_Core_Block_Template
{   
    /**
     * @uses   function used to get all the main countries
     */
    public function getMainCountry()     
    { 
        $mainCountry = array();
        $mainCountry =  Mage::getModel('storelocator/country')->getCollection()->addFieldToFilter('maincountry',1)->addAttributeToSort('sort', 'ASC')->getData();
        if(count($mainCountry) > 0)
        {
            return $mainCountry;
        }
        else
        {
            return $mainCountry;
        }
    }

    /**
     * @uses   function used to get all the states of maincountry (the first country of all main countries )
     */
    function getDefaultStates()
    {
        $mainCountryStates = $this->getMainCountry();
        $mainCountryAllStates =  Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$mainCountryStates[0]['country_id'])->addAttributeToSort('sort', 'ASC')->getData();
        return $mainCountryAllStates;
    }
}


