<?php
/**
 * @uses   class used for access country collection and set country_id as primary key
 */
class Customdr_Storelocator_Model_Mysql4_Country extends Mage_Core_Model_Mysql4_Abstract
{
     public function _construct()
     {
         $this->_init('storelocator/country', 'country_id');
     }
}