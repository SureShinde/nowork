<?php
/**
 * @uses   class used for preparing country form
 */
class Customdr_Storelocator_Block_Adminhtml_Store_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
  protected function _prepareForm()
  {
    $form = new Varien_Data_Form();
    $this->setForm($form);
    $fieldset = $form->addFieldset('store_form',
                                   array('legend'=>'Store Information'));
    
    $fieldset->addField('store_name', 'text',
                 array(
                    'label' => 'Store Name',
                    'class' => 'required-entry',
                    'required' => true,
                     'name' => 'store_name',
              ));
  
    $fieldset->addField('store_address', 'text',
                 array(
                    'label' => 'Address Line 1',
                    'class' => 'required-entry',
                    'required' => true,
                     'name' => 'store_address',
              ));

    $fieldset->addField('store_address_extra', 'text',
                 array(
                    'label' => 'Address Line 2',
                    'name' => 'store_address_extra',
              ));

    $fieldset->addField('store_phone', 'text',
                 array(
                    'label' => 'Phone',
                    'name' => 'store_phone',
              ));

    $fieldset->addField('store_city', 'text',
                 array(
                    'label' => 'City',
                    'name' => 'store_city',
              ));

    $fieldset->addField('store_zip', 'text',
                 array(
                    'label' => 'Zipcode',
                 //   'class' => 'required-entry validate-zip',
                     'class' => 'required-entry',
                     'required' => true,
                     'name' => 'store_zip',
              ));


        $allCountry = Mage::getModel('storelocator/country')->getCollection();
        $_allCountryItems = array();
        
          foreach($allCountry as $item)
          { 
            if($item->getParent == NULL)
            {
                $_allCountryItems[] = array(
                                  'value'     => $item->getCountry_id(),
                                  'label'     => $item->getCountry_name(),
                              );
            }
          } 

        

     
        $note = "select country for your store";
        $country = $fieldset->addField('country_id', 'select', array(
                  'name'      => 'country_id',
                  'label'     => "Select Country",
                  'title'     => "Select Country",
                  'required'  => true,
                  'note'      => $note,
                  'values'    => $_allCountryItems,
                  'onchange' => 'getstate(this)',
                ));


       
        $_statesItems = array();
        $_statesItems[0] = array(
                                  'value'     => 0,
                                  'label'     => 'None',
                              );


        $checknewEntry = Mage::registry('store_data')->getData();
        if ( count($checknewEntry) != 0 )
        {
          $aliasCountry = Mage::registry('store_data')->getCountry_id();
          $states = Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$aliasCountry);
          foreach($states as $item)
          { 
            if($item->getParent == NULL)
            {
                $_statesItems[] = array(
                                  'value'     => $item->getState_id(),
                                  'label'     => $item->getState_name(),
                              );
            }
          } 
        }
        else
        {
          $mainCountry =  Mage::getModel('storelocator/country')->getCollection()->addFieldToFilter('maincountry',1)->getData();
            if(count($mainCountry) > 0)
            {
                $aliasCountry =    $mainCountry[0]['country_id'];
            }
            else
            {
                $mainCountry =  Mage::getModel('storelocator/country')->getCollection()->getData();
                $aliasCountry =    $mainCountry[0]['country_id'];
            }

          $states = Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$aliasCountry);
          foreach($states as $item)
          { 
            if($item->getParent == NULL)
            {
                $_statesItems[] = array(
                                  'value'     => $item->getState_id(),
                                  'label'     => $item->getState_name(),
                              );
            }
          } 
        }

        $fieldset->addField('state_id', 'select', array(
            'name'  => 'state_id',
            'label'     => 'State',
            'values'    => $_statesItems,
        ));      


        /*
         * Add Ajax to the Country select box html output
        */
        $country->setAfterElementHtml("<script type=\"text/javascript\">
            function getstate(selectElement){
                var reloadurl = '". $this
                 ->getUrl('storelocator/adminhtml_state/state') . "country/' + selectElement.value;
                new Ajax.Request(reloadurl, {
                    method: 'get',
                    onLoading: function (stateform) {
                        $('state_id').update('Searching...');
                    },
                    onComplete: function(stateform) {
                        $('state_id').update(stateform.responseText);
                    }
                });
            }
        </script>");

        $note = "enble / disable";
        $fieldset->addField('status', 'select', array(
                      'name'      => 'status',
                      'label'     => "Status",
                      'title'     => "Status",
                      'required'  => true,
                      'note'      => $note,
                      'values'    => array('0' => array( 'value' => 0, 'label' => Enable ),
  '1' => array( 'value' => 1, 'label' => Disable )),
                ));


        $fieldset->addField('sort', 'text',
                       array(
                          'label' => 'Sort Order',
                          'class' => 'required-entry',
                          'required' => true,
                           'name' => 'sort',
                    ));
  if ( Mage::registry('store_data') )
    {
      
      if(count($checknewEntry) == 0)
      {
        $checknewEntry['country_id']  = 48;
      }
      $form->setValues($checknewEntry);
    }
  return parent::_prepareForm();
 }
}