<?php
/**
 * @uses   class used for load country collection
 */
class Customdr_Storelocator_Model_Mysql4_Country_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
 {
     public function _construct()
     {
         parent::_construct();
         $this->_init('storelocator/country');
     }


    public function addAttributeToSort($attribute, $dir='asc')
	{
		if (!is_string($attribute)) {
		return $this;
		}
		$this->setOrder($attribute, $dir);
		return $this;
	} 


}