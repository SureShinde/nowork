<?php
/**
* @uses   class used for preparing state form
*/
class Customdr_Storelocator_Block_Adminhtml_State_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{ 
   /**
   * @uses   function used for preparing all the fields of state form
   */
  protected function _prepareForm()
  {
    $form = new Varien_Data_Form();
    $this->setForm($form);

    $fieldset = $form->addFieldset('state_form',
                                   array('legend'=>'State Information'));

    $fieldset->addField('state_name', 'text',
                   array(
                      'label' => 'State Name',
                      'class' => 'required-entry',
                      'required' => true,
                       'name' => 'state_name',
                ));

    $fieldset->addField('state_code', 'text',
                   array(
                      'label' => 'State Code',
                      'class' => 'required-entry',
                      'required' => true,
                       'name' => 'state_code',
                ));
    
    $allCountry = Mage::getModel('storelocator/country')->getCollection();
    $_allCountryItems = array();
    foreach($allCountry as $item)
    { 
      if($item->getParent == NULL)
      {
          $_allCountryItems[] = array(
                            'value'     => $item->getCountry_id(),
                            'label'     => $item->getCountry_name(),
                        );
      }
    } 

  $note = "select country for your store";
          $fieldset->addField('country_id', 'select', array(
                'name'      => 'country_id',
                'label'     => "Select Country",
                'title'     => "Select Country",
                'required'  => true,
                'note'      => $note,
                'values'    => $_allCountryItems,
          ));
  
  $note = "enble / disable";
  $fieldset->addField('status', 'select', array(
              'name'      => 'status',
              'label'     => "Status",
              'title'     => "Status",
              'required'  => true,
              'note'      => $note,
              'values'    => array('0' => array( 'value' => 0, 'label' => Enable ),
  '1' => array( 'value' => 1, 'label' => Disable )),
        ));

  $fieldset->addField('sort', 'text',
                 array(
                    'label' => 'Sort Order',
                    'class' => 'required-entry',
                    'required' => true,
                     'name' => 'sort',
              ));
        
  if ( Mage::registry('state_data') )
  {
    $form->setValues(Mage::registry('state_data')->getData());
  }
  
  return parent::_prepareForm();
 }
}