<?php
/**
 * @uses   class used for all actions related to storelocator in frontend
 */
class Customdr_Storelocator_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
     * @uses   function used for load layout and set the head title
     */
    public function indexAction()
    {
    	$this->loadLayout();
        $headBlock = $this->getLayout()->getBlock('head');
        $headBlock->setTitle('Store Locator');     
        $this->renderLayout();
    }
    /**
     * @uses   function used for load states
     * @return it return all states in a string
     */
    public function stateAction()
    {
        $post = $this->getRequest()->getPost();
        if($post['type'] == "international")
        {
            $countryList = Mage::getModel('storelocator/country')->getCollection()->addFieldToFilter('maincountry',0)->addFieldToFilter('status',0)->addAttributeToSort('sort', 'ASC');
            $countryList = $countryList->getData(); 
            $_allCountryItems = array();
            $chunkCountryList = array_chunk($countryList, 13);
            $countryString = '<h2 class="stateLable">Country</h2>';
            if(count($chunkCountryList) > 0)
            {
                foreach ($chunkCountryList as $childchunkArray) 
                {   
                    $countryString .= "<ul id='usState'>";
                    foreach ($childchunkArray as $value) 
                    {   
                        $stateID = $value['country_id'];
                        $stateName = $value['country_name'];
                        $countryCode = $value['country_code'];
                        $countryString .= "<li id='state".$stateID."'>";
                        if(strlen($stateName) > 20 )
                        {
                            $shortName = substr(strip_tags($stateName), 0, 20).'....';
                        }
                        else
                        {
                            $shortName = $stateName;
                        }
                        $countryString .= "<a title='".$value['country_name']."' href='javascript:void(0);' onclick=replaceStore0('".$stateID."','international',this); >" . $shortName . "</a>";
                        $countryString .= "</li>";
                    }
                    $countryString .= "</ul>";
                }
            }
            else
            {
                $countryString .= "<li class='noStoreFound'>".$this->getLayout()->createBlock('cms/block')->setBlockId('store-locator-msg')->toHtml()."</li>";
            }    
            print_r($countryString);
            exit;
        }
        else
        {  
            $mainCountryId = $post['id'];
            $countryData = Mage::getModel('storelocator/country')->getCollection()->addFieldToFilter('country_id',$mainCountryId)->getData();
            $usStates = Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$mainCountryId)->addFieldToFilter('status',0)->addAttributeToSort('sort', 'ASC');
            $usStatesArray = $usStates->getData();          
            $chunkStatesArray = array_chunk($usStatesArray, 13);
            $stateLabel = ($countryData[0]['state_label']=="" ? 'States' : $countryData[0]['state_label']); 
            $stateString = '<h2 class="stateLable">'.$stateLabel.'</h2>';
            if(count($chunkStatesArray) > 0 )
            {     
                foreach ($chunkStatesArray as $ChildStatesArray) 
                {   
                    $stateString .= '<ul id="usState">';
                    foreach ($ChildStatesArray as $ChildChunkStatesArray) 
                    {   
                        $stateID = $ChildChunkStatesArray['state_id'];
                        $stateName = $ChildChunkStatesArray['state_name'];
                        $stateString .= "<li id='state".$stateID."'>";
                        if(strlen($stateName) > 20 )
                        {
                            $stateName = substr(strip_tags($stateName), 0, 20).'....';
                        }
                        else
                        {
                            $stateName = $stateName;
                        }
                        $stateString .= "<a title='".$ChildChunkStatesArray['state_name']."'  href='#' onclick=replaceStore0(".$stateID.",'us',this); >" . $stateName . "</a>";
                        $stateString .= "</li>";
                    }   
                    $stateString .= "</ul>";
                }
            }
            else
            {
                $stateString .= "<li class='noStoreFound'>".$this->getLayout()->createBlock('cms/block')->setBlockId('store-locator-msg')->toHtml()."</li>";
            }
            $stateString .= "</ul>";
            print_r($stateString);
            exit;
        }
    }

    /**
     * @uses   function used for load stores
     * @return it return all stores in a string
     */
    public function storeAction()
    {
        $post = $this->getRequest()->getPost();  
        $activeState = $post['activeState']; 
        if($post['type'] == 'international' )
        {
            $stores = Mage::getModel('storelocator/store')->getCollection()->addFieldToFilter('country_id',$post['id'])->addFieldToFilter('status',0);
            $storesArray = $stores->getData();
            $storeString = '<h2 class="storeLable">Stores in <span>'.$activeState.'<span></h2><ul>';
            if(count($storesArray) > 0)
            {   $newln = 1;
                foreach ($storesArray as $ChildStoreArray) 
                {   
                    $storeID = $ChildStoreArray['store_id'];
                    $storecountryId = $ChildStoreArray['country_id'];
                    $stateId = $ChildStoreArray['state_id'];
                    $statNameArray  =       Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('state_id',$ChildStoreArray['state_id']);
                    $statNameArray = $statNameArray->getData();
                    if(isset($ChildStoreArray['store_name']) && $ChildStoreArray['store_name'] != '') { $storeName = $ChildStoreArray['store_name']; } else { $storeName = ''; }
                    if(isset($ChildStoreArray['store_address']) && $ChildStoreArray['store_address'] != '') { $storeAddress = $ChildStoreArray['store_address']; } else { $storeAddress = ''; }
                    if(isset($ChildStoreArray['store_address_extra']) && $ChildStoreArray['store_address_extra'] != '') { $storeAddressExtra = $ChildStoreArray['store_address_extra']; } else { $storeAddressExtra = ''; }
                    if(isset($ChildStoreArray['store_phone']) && $ChildStoreArray['store_phone'] != '') { $storePhone = $ChildStoreArray['store_phone']; } else { $storePhone = ''; }
                    if(isset($ChildStoreArray['store_zip']) && $ChildStoreArray['store_zip'] != '') { $storeZipcode = $ChildStoreArray['store_zip']; } else { $storeZipcode = ''; }
                    if(isset($ChildStoreArray['store_city']) && $ChildStoreArray['store_city'] != '') { $storeCity = $ChildStoreArray['store_city'].','; } else { $storeCity = ''; }
                    if(isset($statNameArray[0]['state_name']) && $statNameArray[0]['state_name'] != '') { $statName = $statNameArray[0]['state_name']; } else { $statName = ''; }
                    if(isset($statNameArray[0]['state_code']) && $statNameArray[0]['state_code'] != '') { $statCode = $statNameArray[0]['state_code']; } else { $statCode = ''; }
                    if($newln %3 == 0)
                    {
                         $class = "last";
                    }
                    else
                    {
                      $class = "";   
                    }
                    $storeString .= "<li id='store".$storeID."' class='".$class."'>";
                    $storeString .= "<h1>".$storeName."</h1>";
                    $storeString .= "<p>".$storeAddress."</p>";
                    $storeString .= "<p>".$storeAddressExtra."</p>";                  
                    $storeString .= "<p>".$storeCity."  ".$statCode."  ".$storeZipcode. "<br>".$storePhone."</p>";
                    $storeString .= "</li>";
                    if($newln %3 == 0)
                    {
                         $storeString .= "<div class='clear'></div>";
                    }
                    $newln++;
                }    
            }
            else
            {
                $storeString .= "<li class='noStoreFound'>".$this->getLayout()->createBlock('cms/block')->setBlockId('store-locator-msg')->toHtml()."</li>";
            }
        }
        else
        {      
            $stores = Mage::getModel('storelocator/store')->getCollection()->addFieldToFilter('state_id',$post['id']);
            $storesArray = $stores->getData();
            $storeString = '<h2 class="storeLable">Stores in <span>'.$activeState.'</span></h2><ul>';
            if(count($storesArray) > 0)
            {   
                $newln = 1;
                foreach ($storesArray as $ChildStoreArray) 
                {   
                    $storeID = $ChildStoreArray['store_id'];
                    $storecountryId = $ChildStoreArray['country_id'];
                    $stateId = $ChildStoreArray['state_id'];
                    $statNameArray  =       Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('state_id',$ChildStoreArray['state_id']);
                    $statNameArray = $statNameArray->getData();
                    if(isset($ChildStoreArray['store_name']) && $ChildStoreArray['store_name'] != '') { $storeName = $ChildStoreArray['store_name']; } else { $storeName = ''; }
                    if(isset($ChildStoreArray['store_address']) && $ChildStoreArray['store_address'] != '') { $storeAddress = $ChildStoreArray['store_address']; } else { $storeAddress = ''; }
                    if(isset($ChildStoreArray['store_address_extra']) && $ChildStoreArray['store_address_extra'] != '') { $storeAddressExtra = $ChildStoreArray['store_address_extra']; } else { $storeAddressExtra = ''; }
                    if(isset($ChildStoreArray['store_phone']) && $ChildStoreArray['store_phone'] != '') { $storePhone = $ChildStoreArray['store_phone']; } else { $storePhone = ''; }
                    if(isset($ChildStoreArray['store_zip']) && $ChildStoreArray['store_zip'] != '') { $storeZipcode = $ChildStoreArray['store_zip']; } else { $storeZipcode = ''; }
                    if(isset($ChildStoreArray['store_city']) && $ChildStoreArray['store_city'] != '') { $storeCity = $ChildStoreArray['store_city'].','; } else { $storeCity = ''; }
                    if(isset($statNameArray[0]['state_name']) && $statNameArray[0]['state_name'] != '') { $statName = $statNameArray[0]['state_name']; } else { $statName = ''; }
                    if(isset($statNameArray[0]['state_code']) && $statNameArray[0]['state_code'] != '') { $statCode = $statNameArray[0]['state_code']; } else { $statCode = ''; }
                    if($newln %3 == 0)
                    {
                         $class = "last";
                    }
                    else
                    {
                      $class = "";   
                    }
                    $storeString .= "<li id='store".$storeID."' class='".$class."'>";
                    $storeString .= "<h1>".$storeName."</h1>";
                    $storeString .= "<p>".$storeAddress."</p>";
                    $storeString .= "<p>".$storeAddressExtra."</p>";

                    $storeString .= "<p>".$storeCity."  ".$statCode."  ".$storeZipcode. "<br>".$storePhone."</p>";
                    $storeString .= "</li>";
                    if($newln %3 == 0)
                    {
                         $storeString .= "<div class='clear'></div>";
                    }
                    $newln++;
                    
                }    
            }
            else
            {
                $storeString .= "<li class='noStoreFound'>".$this->getLayout()->createBlock('cms/block')->setBlockId('store-locator-msg')->toHtml()."</li>";
            }
        }
        $storeString .= "</ul>";
        print_r($storeString);
        exit;
    }
}
