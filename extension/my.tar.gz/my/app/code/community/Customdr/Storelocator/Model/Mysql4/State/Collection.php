<?php
/**
 * @uses   class used for load state collection
 */
class Customdr_Storelocator_Model_Mysql4_State_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
 {
     public function _construct()
     {
         parent::_construct();
         $this->_init('storelocator/state');
     }

	public function addAttributeToSort($attribute, $dir='asc')
	{
		if (!is_string($attribute)) {
		return $this;
		}
		$this->setOrder($attribute, $dir);
		return $this;
	} 

	
}