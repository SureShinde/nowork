<?php
/**
 * @uses   class used for access store collection and set store_id as primary key
 */
class Customdr_Storelocator_Model_Mysql4_Store extends Mage_Core_Model_Mysql4_Abstract
{
     public function _construct()
     {
         $this->_init('storelocator/store', 'store_id');
     }
}