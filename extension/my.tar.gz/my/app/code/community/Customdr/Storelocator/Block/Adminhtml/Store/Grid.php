<?php
 /**
 * @uses   class used for preparing grid list of all stores
 */
class Customdr_Storelocator_Block_Adminhtml_Store_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
  public function __construct()
  {
    parent::__construct();
    $this->setId('storeGrid');
    $this->setDefaultSort('store_id');
    $this->setDefaultDir('DESC');
    $this->setSaveParametersInSession(true);
  }
  /**
   * @uses   function used to get collection of all states
  */
  protected function _prepareCollection()
  {
    $collection = Mage::getModel('storelocator/store')->getCollection();
    $this->setCollection($collection);
    return parent::_prepareCollection();
  }
  /**
   * @uses   function used to peprare columns of grid list
  */
  protected function _prepareColumns()
  {
    $this->addColumn('store_id',
         array(
                'header' => 'ID',
                'align' =>'right',
                'width' => '50px',
                'index' => 'store_id',
           ));
    $this->addColumn('store_name',
           array(
                'header' => 'State Name',
                'align' =>'left',
                'index' => 'store_name',
          ));
    $_menus = Mage::getSingleton('storelocator/country')->getCollection();
    foreach($_menus as $item)
    { 
      $_menuItems[$item->getCountry_id()] = $item->getCountry_name();
    }
    $this->addColumn('country_id',
         array(
              'header' => 'Country',
              'align' =>'left',
              'index' => 'country_id',
              'type'      => 'options',
              'options'    => $_menuItems,
              ));

    $this->addColumn('status',
         array(
              'header' => 'Status',
              'align' =>'left',
              'index' => 'status',
              'type'      => 'options',
              'options'    => array('0' => 'Enable','1' => 'Disable')

        ));

    $this->addColumn('sort',
         array(
              'header' => 'Sort Order',
              'align' =>'left',
              'index' => 'sort',
        ));

    return parent::_prepareColumns();
  }
  /**
   * @uses   function used to peprare edit url
  */
  public function getRowUrl($row)
  {
       return $this->getUrl('*/*/edit', array('id' => $row->getId()));
  }
}