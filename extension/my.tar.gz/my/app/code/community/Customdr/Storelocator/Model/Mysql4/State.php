<?php
/**
 * @uses   class used for access state collection and set state_id as primary key
 */
class Customdr_Storelocator_Model_Mysql4_State extends Mage_Core_Model_Mysql4_Abstract
{
     public function _construct()
     {
         $this->_init('storelocator/state', 'state_id');
     }
}