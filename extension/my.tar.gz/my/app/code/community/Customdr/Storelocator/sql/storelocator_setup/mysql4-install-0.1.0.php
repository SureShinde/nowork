<?php 

$installer = $this;
  $installer->startSetup();

  $installer->run("
    DROP TABLE IF EXISTS {$this->getTable('customdr_galery_country')};


    CREATE TABLE {$this->getTable('customdr_galery_country')} (
      `country_id` int(11) NOT NULL AUTO_INCREMENT,
	  `maincountry` int(2) NOT NULL,
	  `state_label` varchar(255) NOT NULL,
	  `country_name` varchar(255) NOT NULL,
	  `country_code` varchar(255) NOT NULL,
	  `status` int(2) NOT NULL DEFAULT '0',
	  `sort` int(11) NOT NULL,
	  PRIMARY KEY (`country_id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=42 ;


	DROP TABLE IF EXISTS {$this->getTable('customdr_galery_state')};

  CREATE TABLE {$this->getTable('customdr_galery_state')} (
	  `state_id` int(11) NOT NULL AUTO_INCREMENT,
	  `state_name` varchar(255) NOT NULL,
	  `state_code` varchar(255) NOT NULL,
	  `country_id` varchar(255) NOT NULL,
	  `status` int(2) NOT NULL DEFAULT '0',
	  `sort` int(11) NOT NULL,
	  PRIMARY KEY (`state_id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=57 ;


  DROP TABLE IF EXISTS {$this->getTable('customdr_galery_store')};

  CREATE TABLE {$this->getTable('customdr_galery_store')} (
	  `store_id` int(11) NOT NULL AUTO_INCREMENT,
	  `store_name` varchar(255) NOT NULL,
	  `store_address` varchar(255) NOT NULL,
	  `store_address_extra` varchar(255) NOT NULL,
	  `store_phone` varchar(255) NOT NULL,
	  `store_city` varchar(255) NOT NULL,
	  `store_zip` varchar(255) NOT NULL,
	  `country_id` varchar(255) NOT NULL,
	  `state_id` int(11) NOT NULL,
	  `status` int(2) NOT NULL DEFAULT '0',
	  `sort` int(11) NOT NULL,
	  PRIMARY KEY (`store_id`)
	) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=130 ;
  ");
	



 $content = '<h1>No Data Found</h1>';
//if you want one block for each store view, get the store collection
$stores = Mage::getModel('core/store')->getCollection()->addFieldToFilter('store_id', array('gt'=>0))->getAllIds();
//if you want one general block for all the store viwes, uncomment the line below
//$stores = array(0);
foreach ($stores as $store){
    $block = Mage::getModel('cms/block');
    $block->setTitle('Store Locator Msg');
    $block->setIdentifier('store-locator-msg');
    $block->setStores(array($store));
    $block->setIsActive(1);
    $block->setContent($content);
    $block->save();
}
$installer->endSetup();

?>

