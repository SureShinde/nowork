<?php
/**
 * @uses   class used for preparing tabs in country form
 */
class Customdr_Storelocator_Block_Adminhtml_Country_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
  public function __construct()
  {
        parent::__construct();
        $this->setId('country_data');
        $this->setDestElementId('edit_form');
        $this->setTitle('Edit Country');
  }
  protected function _beforeToHtml()
  {
      $this->addTab('form_section', array(
               'label' => 'Country Information',
               'title' => 'Country Information',
               'content' => $this->getLayout()
  ->createBlock('storelocator/adminhtml_country_edit_tab_form')
  ->toHtml()
     ));
     return parent::_beforeToHtml();
  }
}