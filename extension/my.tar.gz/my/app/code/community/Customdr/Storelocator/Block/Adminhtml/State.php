<?php
class Customdr_Storelocator_Block_Adminhtml_State extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    public function __construct()
    {
     //where is the controller
     $this->_controller = 'adminhtml_state';
     $this->_blockGroup = 'storelocator';
     //text in the admin header
     $this->_headerText = Mage::helper('storelocator')->__('State Manager');
     //value of the add button
     $this->_addButtonLabel = 'Add New State';
     parent::__construct();
     }
}