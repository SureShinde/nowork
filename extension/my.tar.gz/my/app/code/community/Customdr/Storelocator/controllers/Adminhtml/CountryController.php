<?php
/**
 * @uses   class used for all actions related to country in backend
*/
class Customdr_Storelocator_Adminhtml_CountryController extends Mage_Adminhtml_Controller_Action
{
      /**
        * @uses   function used load layout
      */
      protected function _initAction()
      {
        $this->loadLayout();
        return $this;
      }
      /**
        * @uses   function used to get states depending on country id
        * @return it returns all states in string 
      */
      public function stateAction() 
      {
        $countrycode = $this->getRequest()->getParam('country');
        $state = "<option value=''>Please Select</option>";
        if ($countrycode != '') {
            $statearray = Mage::getModel('storelocator/state')->getCollection();
            $statearray->addFieldToFilter('country_id',$countrycode);
            $statearray->addFieldToFilter('status',0);
            $statearray1 = $statearray->getdata();
            foreach ($statearray1 as $_state) {
                $state .= "<option value='" . $_state['state_id'] . "'>" . $_state['state_name'] . "</option>";
            }
        }
        echo $state;
      }
      /**
        * @uses   function used to load layout and create dynamic block for country
      */
      public function indexAction()
      { 
        $this->loadLayout()->_setActiveMenu('storelocator/country');
        $this->_addContent($this->getLayout()->createBlock('storelocator/adminhtml_country'));
        $this->renderLayout();
      }
      /**
        * @uses   function used to prepare form for country 
      */
      public function editAction()
      {
          $testId = $this->getRequest()->getParam('id');
          $testModel = Mage::getModel('storelocator/country')->load($testId);
          if ($testModel->getId() || $testId == 0)
          {
             Mage::register('country_data', $testModel);
             $this->loadLayout();
             $this->_setActiveMenu('storelocator/set_time');
             $this->_addBreadcrumb('country Manager', 'country Manager');
             $this->_addBreadcrumb('country Description', 'country Description');
             $this->getLayout()->getBlock('head')
                  ->setCanLoadExtJs(true);
             $this->_addContent($this->getLayout()
                  ->createBlock('storelocator/adminhtml_country_edit'))
                  ->_addLeft($this->getLayout()
                  ->createBlock('storelocator/adminhtml_country_edit_tabs')
              );
             $this->renderLayout();
          }
          else
          {
             Mage::getSingleton('adminhtml/session')
                   ->addError('Store does not exist');
             $this->_redirect('*/*/');
          }
       }
       /**
        * @uses   function used to redirect on edit action at the time of adding new country
      */
       public function newAction()
       {
          $this->_forward('edit');
       }
       /**
        * @uses   function used to save all country information
      */   
       public function saveAction()
       {
        if ($this->getRequest()->getPost())
        {
          try {
              $postData = $this->getRequest()->getPost();
              if( $this->getRequest()->getParam('id') > 0 )
              {
                  if($postData['status'] == 1)
                  {
                    $states = Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$this->getRequest()->getParam('id'))->addFieldToFilter('status',0)->getData();
                    $stores = Mage::getModel('storelocator/store')->getCollection()->addFieldToFilter('country_id',$this->getRequest()->getParam('id'))->addFieldToFilter('status',0)->getData();
                    if(count($states) > 0 || count($stores) > 0)
                    {
                      Mage::getSingleton('adminhtml/session')
                                ->addError('This Country can not be disabled');
                      Mage::getSingleton('adminhtml/session')
                       ->settestData($this->getRequest()
                                          ->getPost()
                      );
                      $this->_redirect('*/*/edit',
                                  array('id' => $this->getRequest()
                                                      ->getParam('id')));
                      return; 
                    }

                  }
              }
              $testModel = Mage::getModel('storelocator/country');
             if( $this->getRequest()->getParam('id') <= 0 )
                $testModel->setCreatedTime(
                   Mage::getSingleton('core/date')
                          ->gmtDate()
                  );
              $testModel
                  ->addData($postData)
                  ->setUpdateTime(
                           Mage::getSingleton('core/date')
                           ->gmtDate())
                  ->setId($this->getRequest()->getParam('id'))
                  ->save();
               Mage::getSingleton('adminhtml/session')
                             ->addSuccess('successfully saved');
               Mage::getSingleton('adminhtml/session')
                              ->settestData(false);
               $this->_redirect('*/*/');
              return;
          } catch (Exception $e){
                Mage::getSingleton('adminhtml/session')
                                  ->addError($e->getMessage());
                Mage::getSingleton('adminhtml/session')
                 ->settestData($this->getRequest()
                                    ->getPost()
                );
                $this->_redirect('*/*/edit',
                            array('id' => $this->getRequest()
                                                ->getParam('id')));
                return;
          }
        }
        $this->_redirect('*/*/');
      }
          
      /**
      * @uses   function used to delete state
      */

      public function deleteAction()
      {
          if($this->getRequest()->getParam('id') > 0)
          {
            try
            {
              /* dependency */
                $states = Mage::getModel('storelocator/state')->getCollection()->addFieldToFilter('country_id',$this->getRequest()->getParam('id'))->addFieldToFilter('status',0)->getData();
                  $stores = Mage::getModel('storelocator/store')->getCollection()->addFieldToFilter('country_id',$this->getRequest()->getParam('id'))->addFieldToFilter('status',0)->getData();
                  if(count($states) > 0 || count($stores) > 0)
                  {
                    Mage::getSingleton('adminhtml/session')
                              ->addError('This Country can not be deleted');
                    Mage::getSingleton('adminhtml/session')
                     ->settestData($this->getRequest()
                                        ->getPost()
                    );
                    $this->_redirect('*/*/edit',
                                array('id' => $this->getRequest()
                                                    ->getParam('id')));
                    return; 
                  }
                /*  dependency  */
                $testModel = Mage::getModel('storelocator/country');
                $testModel->setId($this->getRequest()
                                    ->getParam('id'))
                          ->delete();
                Mage::getSingleton('adminhtml/session')
                           ->addSuccess('successfully deleted');
                $this->_redirect('*/*/');
             }
             catch (Exception $e)
              {
                       Mage::getSingleton('adminhtml/session')
                            ->addError($e->getMessage());
                       $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
              }
         }
        $this->_redirect('*/*/');
   }
}
?>