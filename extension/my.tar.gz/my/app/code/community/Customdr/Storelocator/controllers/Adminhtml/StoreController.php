<?php
/**
 * @uses   class used for all actions related to stores in backend
*/
class Customdr_Storelocator_Adminhtml_StoreController extends Mage_Adminhtml_Controller_Action
{ 
  /**
    * @uses   function used load layout
  */
  protected function _initAction()
  {
  $this->loadLayout();
  return $this;
  }
  /**
    * @uses   function used to get states depending on country id
    * @return it returns all states in string 
  */
  public function stateAction() 
  {
    $countrycode = $this->getRequest()->getParam('country');
    $state = "<option value=''>Please Select</option>";
    if ($countrycode != '') 
    {
      $statearray = Mage::getModel('directory/country')->load($countrycode)->getRegions();
      foreach ($statearray as $_state) 
      {
        $state .= "<option value='" . $_state->getCode() . "'>" . $_state->getDefaultName() . "</option>";
      }
    }
    echo $state;
  }
  /**
    * @uses   function used to load layout and create dynamic block for store
  */
  public function indexAction()
  { 
    $this->loadLayout()->_setActiveMenu('storelocator/store');
    $this->_addContent($this->getLayout()->createBlock('storelocator/adminhtml_store'));
    $this->renderLayout();
  }
  /**
    * @uses   function used to prepare form for store 
  */
  public function editAction()
  {
    $testId = $this->getRequest()->getParam('id');
    $testModel = Mage::getModel('storelocator/store')->load($testId);
    if ($testModel->getId() || $testId == 0)
    {
      Mage::register('store_data', $testModel);
      $this->loadLayout();
      $this->_setActiveMenu('storelocator/set_time');
      $this->_addBreadcrumb('store Manager', 'store Manager');
      $this->_addBreadcrumb('store Description', 'store Description');
      $this->getLayout()->getBlock('head')
      ->setCanLoadExtJs(true);
      $this->_addContent($this->getLayout()
      ->createBlock('storelocator/adminhtml_store_edit'))
      ->_addLeft($this->getLayout()
      ->createBlock('storelocator/adminhtml_store_edit_tabs')
      );
      $this->renderLayout();
    }
    else
    {
      Mage::getSingleton('adminhtml/session')
      ->addError('Store does not exist');
      $this->_redirect('*/*/');
    }
  }
  /**
    * @uses   function used to redirect on edit action at the time of adding new store
  */
  public function newAction()
  {
    $this->_forward('edit');
  }
  /**
    * @uses   function used to save all store information
  */
  public function saveAction()
  {
    if ($this->getRequest()->getPost())
    {
      try 
      {
        $postData = $this->getRequest()->getPost();
        $testModel = Mage::getModel('storelocator/store');
        if( $this->getRequest()->getParam('id') <= 0 )
          $testModel->setCreatedTime(
             Mage::getSingleton('core/date')
                    ->gmtDate()
            );

            $testModel
              ->addData($postData)
              ->setUpdateTime(
                       Mage::getSingleton('core/date')
                       ->gmtDate())
              ->setId($this->getRequest()->getParam('id'))
              ->save();
               Mage::getSingleton('adminhtml/session')
                             ->addSuccess('successfully saved');
               Mage::getSingleton('adminhtml/session')
                              ->settestData(false);
               $this->_redirect('*/*/');
          return;
      } catch (Exception $e)
      {
              Mage::getSingleton('adminhtml/session')
                                ->addError($e->getMessage());
              Mage::getSingleton('adminhtml/session')
               ->settestData($this->getRequest()
                                  ->getPost()
              );
              $this->_redirect('*/*/edit',
                          array('id' => $this->getRequest()
                                              ->getParam('id')));
              return;
      }
    }
    $this->_redirect('*/*/');
  }
  /**
    * @uses   function used to delete store
  */
  public function deleteAction()
  {
    if($this->getRequest()->getParam('id') > 0)
    {
      try
      {
        $testModel = Mage::getModel('storelocator/store');
        $testModel->setId($this->getRequest()
                            ->getParam('id'))
                  ->delete();
        Mage::getSingleton('adminhtml/session')
                   ->addSuccess('successfully deleted');
        $this->_redirect('*/*/');
      }
      catch (Exception $e)
      {
       Mage::getSingleton('adminhtml/session')
            ->addError($e->getMessage());
       $this->_redirect('*/*/edit', array('id' => $this->getRequest()->getParam('id')));
      }
    }
    $this->_redirect('*/*/');
  }
}
?>